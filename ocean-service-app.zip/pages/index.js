
import { useState } from "react";

export default function Home() {
  const [formData, setFormData] = useState({
    nome: "",
    embarcacao: "",
    motor: "",
    chassi: "",
    mecanico: "",
    endereco: "",
    modeloMotor: "",
    combustivel: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      {!submitted ? (
        <div className="w-full max-w-lg p-6 shadow-lg rounded-2xl bg-white">
          <h1 className="text-2xl font-bold text-center mb-6 text-blue-900">
            Cadastro Ocean Service Eletrônica
          </h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input name="nome" placeholder="Nome do Cliente" onChange={handleChange} required className="w-full p-2 border rounded"/>
            <input name="embarcacao" placeholder="Nome da Embarcação" onChange={handleChange} required className="w-full p-2 border rounded"/>
            <div>
              <label className="mr-4"><input type="radio" name="motor" value="BB" onChange={handleChange}/> BB</label>
              <label><input type="radio" name="motor" value="BE" onChange={handleChange}/> BE</label>
            </div>
            <input name="chassi" placeholder="Número do Chassi" onChange={handleChange} required className="w-full p-2 border rounded"/>
            <input name="mecanico" placeholder="Nome do Mecânico" onChange={handleChange} className="w-full p-2 border rounded"/>
            <input name="endereco" placeholder="Endereço completo (CEP, rua, número)" onChange={handleChange} required className="w-full p-2 border rounded"/>
            <input name="modeloMotor" placeholder="Modelo do Motor" onChange={handleChange} required className="w-full p-2 border rounded"/>
            <div>
              <label className="mr-4"><input type="radio" name="combustivel" value="Gasolina" onChange={handleChange}/> Gasolina</label>
              <label><input type="radio" name="combustivel" value="Diesel" onChange={handleChange}/> Diesel</label>
            </div>
            <button type="submit" className="w-full bg-blue-700 text-white py-2 rounded hover:bg-blue-800">
              Gerar Ficha
            </button>
          </form>
        </div>
      ) : (
        <div className="w-full max-w-lg p-6 shadow-lg rounded-2xl bg-white">
          <h2 className="text-xl font-semibold mb-4 text-center text-blue-900">
            Ficha de Cadastro – Ocean Service Eletrônica
          </h2>
          <div className="space-y-2">
            <p><strong>Nome:</strong> {formData.nome}</p>
            <p><strong>Embarcação:</strong> {formData.embarcacao}</p>
            <p><strong>Motor:</strong> {formData.motor}</p>
            <p><strong>Chassi:</strong> {formData.chassi}</p>
            <p><strong>Mecânico:</strong> {formData.mecanico}</p>
            <p><strong>Endereço:</strong> {formData.endereco}</p>
            <p><strong>Modelo do Motor:</strong> {formData.modeloMotor}</p>
            <p><strong>Combustível:</strong> {formData.combustivel}</p>
          </div>
          <div className="mt-6 text-center">
            <p className="font-bold text-blue-900">Ocean Service Eletrônica</p>
            <a href="https://wa.me/5547996177037" target="_blank" rel="noopener noreferrer" className="text-green-600 font-semibold">
              WhatsApp: (47) 9 9617-7037
            </a>
            <div className="flex justify-center mt-4">
              <img src="/logo-ocean.png" alt="Logo Ocean Service" width="180" />
            </div>
          </div>
          <button onClick={() => setSubmitted(false)} className="mt-6 w-full bg-gray-700 text-white py-2 rounded hover:bg-gray-800">
            Novo Cadastro
          </button>
        </div>
      )}
    </div>
  );
}